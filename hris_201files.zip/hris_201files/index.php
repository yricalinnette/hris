<?php session_start();

?>

<!DOCTYPE html>
<html>
  <title>HRIS: 201 File</title>
  <link rel="icon" href="assets/images/logo.png">
  <link href='https://fonts.googleapis.com/css?family=Aclonica' rel='stylesheet'>
  <script src="jquery.js"></script> 
  <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
<style>
.hm {
    border: 3px solid #f1f1f1;
    width: 400px;
    background-color: white;
    border-color: black;
    border-width: 5px;
    border-radius: 10px;
    box-shadow: 0px 0px 30px 1px white;
    background: url(assets/images/lnu.jpg); 
    
}

form{
  background:rgba(20,57,70,.6);
}

img {
  margin: 20px; 
}

body{
  padding-top: 40px;
  background-color: black;
}

input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
    border-radius: 30px;
    opacity: 0.8;
    font-size: 14px;
}

#btn1 {
    background-color: darkblue;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    font-size: 20px;
    border-radius: 30px;
}

#btn1:hover {
    opacity: 0.8;
}

#btn2{
  background-color: green;
  color: white;
  width: 100px;
  padding: 5px;
  border: none;
  box-shadow: 1px 1px 4px 2px black;
  border-radius: 10px;
}

#btn2:hover{
  opacity: 0.9;
  color: black;
  background-color: white;
  font-weight: bold;
}

.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
}

img.avatar {
    width: 30%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
}
</style>
<body>
  <center>
    <div class="hm">
    <form action="index.php" method="POST">
  
        <img src="assets/images/logo.png" alt="Avatar" class="avatar">
        
        <h2 style="font-size: 22px;  font-family: 'aclonica'; color: white; text-shadow: 5px 7px 5px black; margin-top: -20px;">Human Resource <br> Information System: 201 Files</h2>

        <div class="container">
          <label style="padding-right: 300px; font-family: 'aclonica'; font-size: 14px; color: white"> Username</label>
          <input type="text" placeholder="Enter Username" name="username" required autofocus="">

          <label style="padding-right: 300px; font-family: 'aclonica'; font-size: 14px; color: white">Password</label>
          <input type="password" placeholder="Enter Password" name="password" required >
              
          <button  id="btn1" type="submit" name="login23" class="fa fa-sign-in" > Login</button>
        </div>
        </form>
        <div style="background-color:#f1f1f1; padding: 20px;">
          <h4>Register User Account. <a href="pages/register.php" type="button" id="btn2"> Click Here </a></h4>

        </div>
        </div>
      
    </center>
      <?php
              include("admin/connection.php");

              //KADTONG PAG LOGIN BA
              if(isset($_POST['login23']))
              {
                $user=$_POST['username'];
                $pass=$_POST['password'];
                  
                
                $var=mysqli_query($con,"SELECT * FROM tbl_users WHERE username='$user' AND password='$pass'");
                $count=mysqli_num_rows($var);
                
                while($row=mysqli_fetch_array($var))
                  {
                    $_SESSION['id']=$row['users_id'];
                    $_SESSION['name']=$row['username'];
                    $_SESSION['e_id']=$row['employee_id'];
                    $_SESSION['userlevel_id']=$row['userlevel_id'];
                    $_SESSION['file']=$row['file'];
                    $_SESSION['last_login_timestamp'] = time();
                    $_SESSION['first']= $row['first_time_login'];
                  }


                $quer = mysqli_query($con, "SELECT * FROM tbl_employee WHERE employee_id = $_SESSION[e_id]  && status = 'active'");
                  while ($row1=mysqli_fetch_array($quer)) {
                    $stat = $row1['status'];
                  }


                // ASYA INE DINHE AN PAG CHECK IF MAYDA USER ACCOUNT HA DATABASE :)
                if($count == '1')
                {
                  if ($stat == 'active') {
                  
                  //igcheck if first time pala niya mag login
                  if ($_SESSION['first'] == 'logged') {
                    
                      //Ig checheck kun anu an eya userlevel
                      if ($_SESSION['userlevel_id']== '2') 
                      {
                        echo"<script>alert('Welcome $user!');window.location.href='employee/home.php';</script>";
                        mysqli_query($con, "UPDATE tbl_users SET status = 'online' WHERE users_id = '{$_SESSION['id']}'");

                        //mysqli_query($con, "INSERT INTO tbl_logs (activity, log_in) VALUES ('$user logged in ',now()) ");

                        
                      }
                      elseif ($_SESSION['userlevel_id'] == '1') {
                        echo"<script>alert('Welcome $user!');window.location.href='admin/home.php';</script>";
                        mysqli_query($con, "UPDATE tbl_users SET status = 'online' WHERE users_id = '{$_SESSION['id']}'");

                        //mysqli_query($con, "INSERT INTO tbl_logs (user_id ,activity, log_in) VALUES ('{$_SESSION['id']}', '$user logged in ',now()) ");

                      }
                      /*elseif ($_SESSION['userlevel_id'] == '2') {
                        echo"<script>alert('Welcome $user!');window.location.href='director_home.php';</script>";
                        mysqli_query($con, "UPDATE tbl_users SET status = 'online' WHERE users_id = '{$_SESSION['id']}'");

                        //mysqli_query($con, "INSERT INTO tbl_logs (user_id ,activity, log_in) VALUES ('{$_SESSION['id']}', '$user logged in ',now()) ");

                      }*/
                      elseif ($_SESSION['userlevel_id'] == '3') {
                        echo"<script>alert('Welcome $user!');window.location.href='data_encoder/home.php';</script>";
                        mysqli_query($con, "UPDATE tbl_users SET status = 'online' WHERE users_id = '{$_SESSION['id']}'");

                        //mysqli_query($con, "INSERT INTO tbl_logs (user_id ,activity, log_in) VALUES ('{$_SESSION['id']}', '$user logged in ',now()) ");

                      }
                  }else
                  {
                    mysqli_query($con, "UPDATE tbl_users SET first_time_login = 'logged' WHERE users_id = '{$_SESSION['id']}'");
                    header('location: admin/welcome_page.php');
                  }
                }else
                {
                  echo"<script>alert('Account is In-active. Contact HRMO for more details!');window.history.back();</script>";
                }

              }else
                {
                  echo"<script>alert('Account does not exist!');window.history.back();</script>";
                }
            }
          ?>




</body>
</html>