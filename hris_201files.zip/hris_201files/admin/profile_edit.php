<?php session_start();
    if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
    }
    else{
      include ("session_end.php");
    
    }
?>
<!doctype html>
<html lang="en">
<head>
	<title>HRIS: 201 File</title>
    <link rel="icon" href="../assets/images/logo.png">
    <!-- Bootstrap core CSS     -->
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>

    <!--Style-->
    <style type="text/css">
        .card-body{
            padding: 20px;
        }
        .card {
            margin: 0 auto;
            float: none;
            margin-bottom: 10px;
        }
        input[type=text], input[type=password], select[type=select] {
            padding: 12px 20px;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 8px;
        }
        .results tr[visible='false'],
        .no-result{
          display:none;
        }

        .results tr[visible='true']{
          display:table-row;
        }

        .counter{
          padding:8px; 
          color:#ccc;
        }
    </style>

</head>
<body>

<div class="wrapper">

    <?php
        include ("connection.php");

        $var= mysqli_query($con,"SELECT * FROM tbl_users WHERE users_id='$_SESSION[id]' ");
        $count=mysqli_num_rows($var);
          //echo $count;
          //I only specifies the admin accesslevel, if the $count=1, meaning the logged account is administrator or admin, else student or user

        if ($count)
        {
            if ($_SESSION['userlevel_id']== '1') {
    ?>

    <!--Kanan ha side bar-->
    <div class="sidebar" data-background-color="white" data-active-color="info">
        <div class="sidebar-wrapper">
            <div class="logo">
                <?php include "../templates/profile.php"; ?>
            
            </div>
            <ul class="nav">
                <li>
                    <a href="home.php">
                        <i class="ti-dashboard" style="height: 30px; width: 30px"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="upload_doc.php">
                        <i class="ti-upload" style="height: 30px; width: 30px"></i>
                        <p>Upload Document</p>
                    </a>
                </li>
                <li>
                    <a href="all_documents.php">
                        <i class="ti-book" style="height: 30px; width: 30px"></i>
                            <p>Documents</p>
                    </a>
                </li>
                <li>
                    <a href="all_employee.php">
                        <i class="ti-user" style="height: 30px; width: 30px"></i>
                            <p>Employees</p>
                    </a>
                </li>
                <li>
                    <a href="all_request.php">
                        <i class="ti-notepad" style="height: 30px; width: 30px"></i>
                            <p>Requests</p>
                    </a>
                </li>
                <li   class="active">
                    <a href="profile.php">
                        <i class="ti-info-alt" style="height: 30px; width: 30px"></i>
                            <p>Account Settings</p>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="ti-settings" style="height: 30px; width: 30px"></i>
                            <p>Settings</p>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i><img src="../assets/img/logout.ico" style="height: 30px; width: 30px"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </div>
    </div><!--End han side bar-->

    <?php  
            }elseif ($_SESSION['userlevel_id']== '2') {
                include ('../templates/mis.php');
            }elseif ($_SESSION['userlevel_id']== '3') {
                include ('../templates/panel_encoder.php');
            }elseif ($_SESSION['userlevel_id']== '4') {
              include ('../templates/panel_employee.php');
            }
        }

        $key = $_GET['id'];
        $q = mysqli_query($con, "SELECT * from tbl_employee WHERE  employee_id= $key");

        while ($row=mysqli_fetch_array($q)) {
            $fname = $row['firstname'];
            $mname =$row['middlename'];
            $lname =$row['lastname'];
            $ename =$row['extension_name'];
            $idnum = $row['id_number'];
            $nick = $row['nickname'];
            $num = $row['employee_id'];
        }

        
    ?>

    <!--Main panel ini-->
    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">MY PROFILE</a>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-1"></div>
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="header">
                                <div class="columns columns-right pull-right">
                                   <!--<h4><b><i class="fa fa-user"></i> PERSONAL INFORMATION</b></h4>-->
                                    <table>
                                      <tbody>
                                        <?php
                                          include ('connection.php');

                                          $query = mysqli_query($con, "SELECT * FROM tbl_employee WHERE employee_id=$key");

                                          while ($row = mysqli_fetch_array($query)) {
                                            $stat = $row['status'];

                                            echo "<tr>";
                                                              
                                              
                                              if ($stat == 'active') {
                                                echo "<td>
                                                  <div >
                                                    <a href='employee_documents.php?key=$num' class='btn btn-primary btn-sm ' style='width: 200px; font-size: 14px;'><b>View My Document</b></a>
                                                    <a href='profile.php' class='btn btn-danger btn-sm' style='width: 200px; font-size: 14px;' ><b>BACK</b></a>
                                                  </div>
                                                  </td>";
                                              } else {
                                                echo "<td>
                                                  <div style='margin-left:400px;'>
                                                    <a href='employee_view_documents.php?key=$num' class='btn btn-primary btn-sm' style='width: 200px; font-size: 14px;'><b>View Employee's Document</b></a>
                                                    <a href='active.php?set1=true6&&key=$num' class='btn btn-success btn-sm' style='width: 200px; font-size: 14px;'><b>ACTIVATE</b></a>
                                                  </div>
                                                </td>";
                                              }
                                            echo "</tr>";
                                            }           
                                          
                                        ?>
                                      </tbody>
                                    </table>
                                </div>

                                
                            </div>
                        <div class="row">
          
                          <!-- <input type="hidden" id="user_info_id" value=""> -->
                          <div class="col-xs-12">
                                  <div class="col-xs-7">
                                   <form  action="process.php" method="POST"  style="padding: 10px; color: black;">


                                    <input class="form-control" id="lname" name="use_id" type="hidden" value="<?php print ($num)?>">


                                    <table class="tbl" >
                                        <tr> 
                                            <td>
                                                <label>ID NUMBER</label>
                                                <input class="form-control" id="idnum" name="idnum" type="text" value="<?php print ($idnum)?>">
                                            </td>
                                            
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>LASTNAME</label>
                                                <input class="form-control" id="lname" name="lname" type="text" value="<?php print ($lname)?>">
                                            </td>
                                        </tr>
                                        <tr>
                                             <td>
                                                <label>FIRSTNAME</label>
                                                <input class="form-control fwidth-2" id="fname" name="fname" type="text" value="<?php print ($fname)?>">
                                            </td>
                                            
                                        </tr>
                                        <tr > 
                                            <td>
                                                <label>MIDDLENAME</label>
                                                <input class="form-control fwidth-2" id="mname" name="mname" type="text" value="<?php print ($mname)?>">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>EXTENSION NAME</label> 
                                                <input class="form-control fwidth-2" id="ename" name="ename" type="text" value="<?php print ($ename)?>">  
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label>NICKNAME</label>
                                                <input class="form-control fwidth-2" id="nname" name="nname" type="text" value="<?php print ($nick)?>">
                                            </td>

                                            
                                        </tr>
                                        <tr class="edit-cont">
                                            
                                            <td>
                                              <label>ACADEMIC RANKS</label>
                                                  <select type="select" class="form-control" id="aranks" name="aranks" value="" required="">
                                                    <option value="" disabled="" selected>
                                                    
                                                    </option>
                                                    <?php
                                                      include ("connection.php");
                                                        $sql = "SELECT * FROM tbl_academic_ranks";
                                                        $query = mysqli_query($con, $sql);

                                                        while ($row = mysqli_fetch_array($query)){

                                                          echo "<option value=".$row['academic_rank_id']."> ".$row['academic_rank']. "</option>";
                                                        }
                                                            
                                                    ?>
                                                  </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                              <label>UNIVERSITY POSITION</label>
                                                    <select type="select" class="form-control"  id="uposition" name="uposition" required="">
                                                        <option value="" disabled="" selected>
                                                         </option>
                                                          <?php
                                                            include ("connection.php");
                                                                $sql = "SELECT * FROM tbl_university_position";
                                                                $query = mysqli_query($con, $sql);

                                                                while ($row = mysqli_fetch_array($query)){

                                                                  echo "<option value=".$row['university_position_id']. "> ".$row['university_position']."</option>";
                                                                }
                                                                
                                                          ?>
                                                    </select>
                                                  <button id="add-btn" class="btn btn-large btn-success" name='update_emp' data-loading-text="Adding..." style="margin-top: 20px;">Save Changes</button>
                                            </td>
                                        </tr>
                                    </table>

                                    </form>
                                  </div>
                                  <div class="col-md-4">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <img src="../assets/images/<?php 
                                    $qe = mysqli_query($con, "SELECT * FROM tbl_employee WHERE employee_id = $key");
                                    while ($row = mysqli_fetch_array($qe)) {
                                      $pic = $row['file'];
                                    }
                                    echo $pic;

                                     ?> " style = "width: 250px; margin-top: 20px; border-width: 3px; border-style: solid; border-color: black;">
                                    </a>
                                    <form action="process.php" method="POST" enctype="multipart/form-data">

                                      <input class="form-control" id="lname" name="id_pic" type="hidden" value="<?php print ($num)?>">


                                    <div class="form-group" style="margin-top: 10px;">
                                      <input type="file" name="myfile2" class="form-control" style="width: 250px;">
                                      <button id="add-btn" type="submit" class="btn btn-large btn-success" name='user_pic' data-loading-text="Adding..." style="margin-top: 20px;">Save Changes</button> 
                                    </div>
                                    </form>
                                    
                                    <div class="form-group" style="margin-top: 10px; color: black;">
                                      <br><h4><b>Account Settings</b></h4>
                                      <form action="process.php" method="POST">
                                        <?php
                                            include ("connection.php");
                                            $q = mysqli_query($con, "SELECT * FROM tbl_users WHERE employee_id = $key");

                                            while ($row=mysqli_fetch_array($q)) {
                                              $user = $row['username'];
                                              $pass =$row['password'];
                                              
                                          }

                                          ?>
                                        <input class="form-control" id="lname" name="id_acc" type="hidden" value="<?php print ($num)?>">
                                        <label>Username</label>
                                        <input type="text" name="user123" class="form-control" style="width: 250px;" placeholder="Username" value="<?php print ($user) ?>">

                                        <label>Password</label>
                                        <input type="password" name="pass123" class="form-control" style="width: 250px;" placeholder="Username"  value="<?php print ($pass) ?>">
                                        <button id="add-btn" class="btn btn-large btn-success" name='update_account' data-loading-text="Adding..." style="margin-top: 20px;">Save Changes</button> 
                                      </form>
                                    </div>
                                    
                                  </div>
                              </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--Content lwat adi na end-->


         <footer class="footer">
            <div class="container-fluid">
                <div class="copyright pull-right">
                    &copy; 2017,<i class="fa fa-briefcase"></i> LNU:HRMO by: ALT+F4 </a>
                </div>
            </div>
        </footer>

    </div><!--End han Main panel ini-->
</div><!--End han wrapper lwat-->

</body>
    <!-- Ha date ngan time -->
    <script>
        var dt = new Date();
            document.getElementById("datetime").value = dt.toLocaleString();
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
      $(".search").keyup(function () {
        var searchTerm = $(".search").val();
        var listItem = $('.results tbody').children('tr');
        var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
        
      $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
            return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
        }
      });
        
      $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','false');
      });

      $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','true');
      });

      var jobCount = $('.results tbody tr[visible="true"]').length;
        $('.counter').text(jobCount + ' item');

      if(jobCount == '0') {$('.no-result').show();}
        else {$('.no-result').hide();}
          });
    });
    </script>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
