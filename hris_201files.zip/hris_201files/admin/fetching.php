<?php
$query = mysqli_query($con, "SELECT * from tbl_employee WHERE employee_id = '{$_SESSION['e_id']}'");

	while ($row=mysqli_fetch_array($query)) {
            $file = $row['file'];
            $status = $row['status'];
            $nickname = $row['nickname'];
            
        }

?>