<?php
	include ('connection.php');

	

	if(isset($_POST['deactivate']))
	{
		$id2 = $_POST['id123'];
		$reason = $_POST['reason'];
		
		mysqli_query($con,"UPDATE tbl_employee SET status= 'inactive', reason = '$reason' where employee_id = '$id2'");
		echo"<script>alert('Successfully deactivated employee account. ');window.location.href='all_employees.php';</script>";
	}
	 

?>