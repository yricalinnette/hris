<?php session_start();

?>
<?php
include("connection.php");

	if ($_GET['set1']=='true1')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_userlevel WHERE userlevel_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='userlevel.php';</script>";
		
	}

	if ($_GET['set1']=='true2')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_announcements WHERE announcements_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='settings.php';</script>";
		
	}

	if ($_GET['set1']=='true3')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_document_type WHERE document_type_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='document_type.php';</script>";
		
	}


	if ($_GET['set1']=='true4')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_academic_ranks WHERE academic_rank_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='academic_ranks.php';</script>";
		
	}


	if ($_GET['set1']=='true5')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_university_position WHERE university_position_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='university_position.php';</script>";
		
	}

	
	// For Approval of Requested documents
	if ($_GET['set1'] == 'true6') {
		$id = (isset($_GET['id']) ? $_GET['id'] : '');

		mysqli_query($con, "UPDATE tbl_requests SET status = 'Approved' WHERE request_id = '$id' ");
		echo"<script>alert('Approval of Request done.');window.location.href='admin_all_request.php';</script>";
	}


	// For Disapproval of Requested documents
	if ($_GET['set1'] == 'true7') {
		$id = (isset($_GET['id']) ? $_GET['id'] : '');

		mysqli_query($con, "UPDATE tbl_requests SET status = 'Disapproved' WHERE request_id = '$id' ");
		echo"<script>alert('Disapproval of Request done.');window.location.href='admin_all_request.php';</script>";
	}		


	// For APPROVAL of Uploaded documents of employee
	if ($_GET['set1'] == 'true8') {
		$id = (isset($_GET['id']) ? $_GET['id'] : '');

		mysqli_query($con, "UPDATE tbl_document SET status = 'Approved' WHERE document_id = '$id' ");
		echo"<script>alert('Approval of Uploaded Document done.');window.location.href='all_documents.php';</script>";
	}		

	// For DISAPPROVAL of Uploaded documents of employee
	if ($_GET['set1'] == 'true9') {
		$id = (isset($_GET['id']) ? $_GET['id'] : '');

		mysqli_query($con, "UPDATE tbl_document SET status = 'Disapproved' WHERE document_id = '$id' ");
		echo"<script>alert('Approval of Uploaded Document done.');window.location.href='all_documents.php';</script>";
	}		


	//DELETE the request for documents selected
	if ($_GET['set1']=='true10')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_requests WHERE request_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='all_request.php';</script>";
		
	}

	if ($_GET['set1']=='true20')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_users WHERE users_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='data_encoder.php';</script>";
		
	}


	if ($_GET['set1']=='true21')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_requests WHERE request_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='employee_all_requests.php';</script>";
		
	}


	if ($_GET['set1']=='true22')
	{
		$id = (isset($_GET['id']) ? $_GET['id'] : '');
		
		mysqli_query($con,"DELETE FROM tbl_requests WHERE request_id='$id'");
		echo"<script>alert('Deleted successfully.');window.location.href='admin_pending_requests.php';</script>";
		
	}

?>