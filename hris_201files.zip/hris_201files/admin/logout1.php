

<?php
session_start();
?>
<!DOCTYPE  html>
<html>
	<head><title>Opps! WARNING.</title>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="favicon.ico">
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	
	 <style type="text/css"> 
      body{
        font-family: Microsoft YaHei UI Light;
      } </style> 

	</head>
	<body>
		<div class="container animated fadeIn">
	

		<div class="col-lg-3"></div>
		<div class="col-lg-6">
		<center>
			<img src="../assets/images/session-expired.png" style="margin-top: 100px;">
			<h1 style="margin-top: 20px;"><b>Ooooopsss!</b></h1>
					<h2>SESSION EXPIRED AND DESTROYED!</h2>
					<div style="height: 5px;"></div>
					
								<h4>Please login to Continue</h4>
								<a href="../index.php" ><button class="btn btn-primary" >LOGIN</button></a>
		</center>
		</div>	
		<div class="col-lg-3"></div>		
		</div>


		<div class="container" style="padding-top: 60px;">
			<div class="col-lg-4"></div>
			
				<div style="text-align: center; margin-top: 100px;">
                            <small>Human Resource Information System: 201 Files</small><br>
                            <small>All rights reserved.</small>
				</div>
			</div>
		</div>
	</body>
</html>

<?php session_destroy(); ?>