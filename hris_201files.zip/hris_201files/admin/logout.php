<?php
	session_start();
	include ('connection.php');
	mysqli_query($con, "UPDATE tbl_users SET status = 'offline' WHERE users_id = '{$_SESSION['id']}'");

	//mysqli_query($con, "UPDATE tbl_logs SET log_out = now()");

	echo"<script>alert('Successfully logout.');window.location.href='../index.php';</script>";

	session_destroy();
?>hom