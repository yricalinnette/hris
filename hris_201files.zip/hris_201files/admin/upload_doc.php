<?php session_start();
    if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
    }
    else{
      include ("session_end.php");
    
    }
?>

<!doctype html>
<html lang="en">
<head>
    <title>HRIS: 201 File</title>
    <link rel="icon" href="../assets/images/logo.png">
    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="../assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/themify-icons.css" rel="stylesheet">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>

    <!--Style-->
    <style type="text/css">
        .card-body{
            padding: 20px;
        }
        .card {
            margin: 0 auto;
            float: none;
            margin-bottom: 10px;
        }
        input[type=date], input[type=file], select, textarea[type=textarea] {
            padding: 12px 20px;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 8px;
        }
        .results tr[visible='false'],
        .no-result{
          display:none;
        }

        .results tr[visible='true']{
          display:table-row;
        }

        .counter{
          padding:8px; 
          color:#ccc;
        }
    </style>

</head>
<body>

<div class="wrapper">

    <?php
        include ("connection.php");

        $var= mysqli_query($con,"SELECT * FROM tbl_users WHERE users_id='$_SESSION[id]' ");
        $count=mysqli_num_rows($var);
          //echo $count;
          //I only specifies the admin accesslevel, if the $count=1, meaning the logged account is administrator or admin, else student or user

        if ($count)
        {
            if ($_SESSION['userlevel_id']== '1') {
    ?>

    <!--Kanan ha side bar-->
    <div class="sidebar" data-background-color="white" data-active-color="info">
        <div class="sidebar-wrapper">
            <div class="logo">
                <?php include "../templates/profile.php"; ?>
            
            </div>
            <ul class="nav">
                <li>
                    <a href="home.php">
                        <i class="ti-dashboard" style="height: 30px; width: 30px"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li  class="active">
                    <a href="upload_doc.php">
                        <i class="ti-upload" style="height: 30px; width: 30px"></i>
                        <p>Upload Document</p>
                    </a>
                </li>
                <li>
                    <a href="all_documents.php">
                        <i class="ti-book" style="height: 30px; width: 30px"></i>
                            <p>Documents</p>
                    </a>
                </li>
                <li>
                    <a href="all_employee.php">
                        <i class="ti-user" style="height: 30px; width: 30px"></i>
                            <p>Employees</p>
                    </a>
                </li>
                <li>
                    <a href="all_request.php">
                        <i class="ti-notepad" style="height: 30px; width: 30px"></i>
                            <p>Requests</p>
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="ti-info-alt" style="height: 30px; width: 30px"></i>
                            <p>Account Settings</p>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="ti-settings" style="height: 30px; width: 30px"></i>
                            <p>Settings</p>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i><img src="../assets/img/logout.ico" style="height: 30px; width: 30px"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </div>
    </div><!--End han side bar-->

    <?php  
            }elseif ($_SESSION['userlevel_id']== '2') {
                include ('../templates/mis.php');
            }elseif ($_SESSION['userlevel_id']== '3') {
                include ('../templates/panel_encoder.php');
            }elseif ($_SESSION['userlevel_id']== '4') {
              include ('../templates/panel_employee.php');
            }
        }
    ?>

    <!--Main panel ini-->
    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">Upload Documents</a>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="content">
                                <form action="process.php" method="POST" enctype="multipart/form-data" id="up">
                                <label for="document_type_id">SELECT DOCUMENT</label  >
                                  <select name="subject" id="document_type_id" class="form-control livesearch">
                                    <option value="" disabled selected>Select document type...</option>
                                    <?php
                                      include ("connection.php");
                                          $sql = "SELECT * FROM tbl_document_type";
                                          $query = mysqli_query($con, $sql);

                                          while ($row = mysqli_fetch_array($query)){

                                            echo '<option value = '.$row['document_type_id'].'>'.$row['document_type'].'</option>';
                                          }
                                          
                                    ?>
                                  </select>
                              
                                <div class="form-group" style="padding-top: 15px;">
                                  <label for="date_issued" id="lbl_date_issued">DATE SUBMITTED</label>
                                  <input type="date" class="form-control dtpkr" name="date_issued" id="date_issued" placeholder="yyyy-mm-dd">
                                </div>
                                <div class="form-group" id="num-group">
                                  <label for="number"><span id="order-title">DESCRIPTION</span></label>
                                  <textarea type="textarea" name="description" id="description" class="form-control" rows="5"></textarea>
                                </div>
                                <div id="emp-group">
                                  <div class="form-group">
                                    <label for="emp_search">Employee</label>
                                    
                                      <select id="employee" name="employee" class="form-control livesearch" >
                                        <option value = ""></option>
                                            <?php
                                                $result = mysqli_query($con,"SELECT * FROM tbl_employee");
                                                while($row = mysqli_fetch_array($result)) {
                                                    echo '<option value='.$row['employee_id'].'>'.$row['lastname'].', '.$row['firstname'].'</option>';
                                                }
                                            ?> 
                                    </select>
                                  
                                  </div>
                                  
                                  <div class="form-group">
                                    <input type="hidden" name="employees[]" value="0" />
                                  <div id="emp-tags"></div>
                                  </div>
                                </div>
                                
                                <!--<div class="form-group">
                                  <label for="subject">Subject <span class="text-help">(Enter keywords that best describes the document.)</span></label>
                                  <input type="text" class="form-control" name="subject" id="subject" placeholder="">
                                </div>-->
                                <div class="form-group">
                                  <label for="venue">PDF File</label>
                                  <input type="file" name="myfile" class="form-control">
                                </div>
                                <hr>
                                <center>
                                <div class="form-group">
                                  <button id="up-btn" class="btn btn-primary  " data-loading-text="Uploading document..." type="submit" name="upload_docs"><i class="fa fa-fw fa-upload"></i>Upload Document </button>
                                  &nbsp<button class="btn btn-danger" type="reset">Clear Form</button>
                                </div></center>
                              </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--Content lwat adi na end-->


         <footer class="footer">
            <div class="container-fluid">
                <div class="copyright pull-right">
                    &copy; 2017,<i class="fa fa-briefcase"></i> LNU:HRMO by: ALT+F4 </a>
                </div>
            </div>
        </footer>

    </div><!--End han Main panel ini-->
</div><!--End han wrapper lwat-->

</body>
    <!-- Ha date ngan time -->
    <script>
        var dt = new Date();
            document.getElementById("datetime").value = dt.toLocaleString();
    </script>
    <script type="text/javascript">
      $(".livesearch").chosen();
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
      $(".search").keyup(function () {
        var searchTerm = $(".search").val();
        var listItem = $('.results tbody').children('tr');
        var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
        
      $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
            return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
        }
      });
        
      $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','false');
      });

      $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','true');
      });

      var jobCount = $('.results tbody tr[visible="true"]').length;
        $('.counter').text(jobCount + ' item');

      if(jobCount == '0') {$('.no-result').show();}
        else {$('.no-result').hide();}
          });
    });
    </script>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Checkbox, Radio & Switch Plugins -->
    <script src="assets/js/bootstrap-checkbox-radio.js"></script>

    <!--  Charts Plugin -->
    <script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
    <script src="assets/js/paper-dashboard.js"></script>

    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="assets/js/demo.js"></script>


</html>
