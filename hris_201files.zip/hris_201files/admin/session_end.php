<?php
	if((time() - $_SESSION['last_login_timestamp']) > 900) // 900 = 15 * 60  
           {  
                header("location:logout1.php");  
           }  
           else  
           {  
                
           }  
?>