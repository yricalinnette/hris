<?php session_start();

	include ("connection.php");


	if(isset($_POST['add_employee']))
	{
		$idnum = $_POST['idnum'];
		$nname = $_POST['nname'];
		$lname = $_POST['lname'];
		$fname = $_POST['fname'];
		$mname = $_POST['mname'];
		$ename = $_POST['ename'];
		$arank = $_POST['aranks'];
		$uposition = $_POST['uposition'];
		
		

		$sql= "INSERT INTO tbl_employee (id_number, lastname, firstname, middlename, extension_name, nickname, status, academic_rank_id, university_position_id, file, path ) VALUES ('$idnum', '$lname', '$fname', '$mname', '$ename', '$nname', 'active', '$arank', '$uposition', 'default.png', 'images/default.png')";

		if (mysqli_query($con, $sql)) {
		 	"SELECT LAST_INSERTED_ID() INTO @tbl_employee";

			$sql = mysqli_query($con, "INSERT INTO tbl_personal_information (employee_id) VALUES( @tbl_employee)");
			echo"<script>alert('Successfully added new Employee !');window.location.href='add_employee.php';</script>";
		 } 
		
	}



	if (isset($_POST['add_announcement'])) {
		$Today = date('y:m:d');
		$time = date_default_timezone_set("Asia/Manila");

		$title = $_POST['title'];
		$desc = $_POST['description'];
		$date = date('F d, Y', strtotime($Today));
		$timenow =date ('g:i A' ,time());



		mysqli_query($con,"INSERT INTO tbl_announcements (announcement_title, announcement_desc, date, time_sub) VALUES ('$title', '$desc', '$date', '$timenow')");
    	echo"<script>alert('Successfully added $title!');window.location.href='settings.php';</script>";
	}


	if (isset($_POST['add_document_type'])) {
		$title = $_POST['title'];

		mysqli_query($con,"INSERT INTO tbl_document_type (document_type) VALUES ('$title')");
    	echo"<script>alert('Successfully added $title!');window.location.href='document_type.php';</script>";
	}


	if (isset($_POST['add_userlevel'])) {
		$level = $_POST['level'];

		mysqli_query($con,"INSERT INTO tbl_userlevel (user_level) VALUES ('$level')");
    	echo"<script>alert('Successfully added $level!');window.location.href='userlevel.php';</script>";
	}


	if (isset($_POST['add_academic_rank'])) {
		$rank = $_POST['rank_no'];
		$title = $_POST['title'];
		$salary = $_POST['salary'];
		$points = $_POST['points'];

		mysqli_query($con,"INSERT INTO tbl_academic_ranks (rank, academic_rank, salary_grade, points) VALUES ('$rank', '$title', '$salary', '$points')");
    	echo"<script>alert('Successfully added $title!');window.location.href='academic_ranks.php';</script>";
	}


	if (isset($_POST['add_university_position'])) {
		$title = $_POST['title'];

		mysqli_query($con,"INSERT INTO tbl_university_position (university_position) VALUES ('$title')");
    	echo"<script>alert('Successfully added $title!');window.location.href='university_position.php';</script>";
	}


	
	if (isset($_POST['upload_docs'])){
            $date = $_POST['date_issued'];
            $desc = $_POST['description'];
            $sub = $_POST['subject'];
            $emp = $_POST['employee'];
            $name = $_FILES['myfile']['name'];
            $tmp_name = $_FILES['myfile']['tmp_name'];

            if ($name){

                $location = "../documents/$name";
                move_uploaded_file($tmp_name, $location); 
                $query   = mysqli_query($con,"INSERT INTO tbl_document (description, date_upload, subject, file ,path, employee, status ) VALUES ('$desc', '$date', '$sub', '$name', '$location','$emp', 'Approved')");
                echo"<script>alert('Successfully added!');window.location.href='upload_doc.php';</script>";

            }else{
                echo"<script>alert('Please select file!');window.history.back();</script>";
            }
            
        }


        if (isset($_POST['upload_docs3'])){
            $date = $_POST['date_issued'];
            $desc = $_POST['description'];
            $sub = $_POST['subject'];
            $emp = $_POST['employee'];
            $name = $_FILES['myfile']['name'];
            $tmp_name = $_FILES['myfile']['tmp_name'];

            if ($name){

                $location = "../documents/$name";
                move_uploaded_file($tmp_name, $location); 
                $query   = mysqli_query($con,"INSERT INTO tbl_document (description, date_upload, subject, file ,path, employee, status ) VALUES ('$desc', '$date', '$sub', '$name', '$location','$emp', 'Approved')");
                header('Location: data_encoder_upload.php');

            }else{
                echo"<script>alert('Please select file!');window.history.back();</script>";
            }
            
        }




        if (isset($_POST['upload_docs_user'])){
            $date = $_POST['date_issued'];
            $desc = $_POST['description'];
            $sub = $_POST['subject'];
            $emp = $_POST['employee'];
            $name = $_FILES['myfile']['name'];
            $tmp_name = $_FILES['myfile']['tmp_name'];

            if ($name){

                $location = "../documents/$name";
                move_uploaded_file($tmp_name, $location); 
                $query   = mysqli_query($con,"INSERT INTO tbl_document (description, date_upload, subject, file ,path, employee, status ) VALUES ('$desc', '$date', '$sub', '$name', '$location','{$_SESSION['e_id']}', 'Pending')");
                header('Location: document_types.php');

            }else{
                echo"<script>alert('Please select file!');window.history.back();</script>";
            }
            
        }





        if (isset($_POST['update_pic'])) {
        	$key = $_POST['id_pic'];

        	$name2 = $_FILES['myfile2']['name'];
        	$tmp_name2 = $_FILES['myfile2']['tmp_name'];

        	if ($name2){
        		$location2 = "../assets/images/$name2";
        		move_uploaded_file($tmp_name2, $location2); 
        		$query   = mysqli_query($con,"UPDATE tbl_employee SET file = '$name2', path = '$location2' WHERE employee_id = '$key' ");
        		echo"<script>alert('Successfully updated profile picture!');window.location.href='all_employees.php';</script>";

        	}else{
                echo"<script>alert('Please select a picture!');window.history.back();</script>";
            }
        }



        if (isset($_POST['user_pic'])) {
        	$key = $_POST['id_pic'];

        	$name2 = $_FILES['myfile2']['name'];
        	$tmp_name2 = $_FILES['myfile2']['tmp_name'];

        	if ($name2){
        		$location2 = "../assets/images/$name2";
        		move_uploaded_file($tmp_name2, $location2); 
        		$query   = mysqli_query($con,"UPDATE tbl_employee SET file = '$name2', path = '$location2' WHERE employee_id = '$key' ");
        		echo"<script>alert('Successfully updated profile picture!');window.location.href='profile_edit.php?id=$key';</script>";

        	}else{
                echo"<script>alert('Please select a picture!');window.history.back();</script>";
            }
        }



        if (isset($_POST['user_picture'])) {
        	$key = $_POST['id_pic'];

        	$name2 = $_FILES['myfile2']['name'];
        	$tmp_name2 = $_FILES['myfile2']['tmp_name'];

        	if ($name2){
        		$location2 = "../assets/images/$name2";
        		move_uploaded_file($tmp_name2, $location2); 
        		$query   = mysqli_query($con,"UPDATE tbl_employee SET file = '$name2', path = '$location2' WHERE employee_id = '$key' ");
        		echo"<script>alert('Successfully updated profile picture!');window.location.href='employee_profile_edit.php?id=$key';</script>";

        	}else{
                echo"<script>alert('Please select a picture!');window.history.back();</script>";
            }
        }



        if (isset($_POST['add_request'])) {
        	$Today = date('y:m:d');
			$date = date('F d, Y', strtotime($Today));
			$time = date_default_timezone_set("Asia/Manila");
			$timenow =date ('g:i A' ,time());

        	$type = $_POST['type'];
        	$desc = $_POST['desc'];
        	$purpose =$_POST['purpose'];
        	$return = $_POST['return'];
        	$request_by =$_POST['request_by'];

        	mysqli_query($con, "INSERT INTO tbl_requests (request_type, description, purpose, date_req, time_req, requested_by, return_on, employee_id, status) VALUES ('$type', '$desc', '$purpose', '$date', '$timenow', '$request_by', '$return', '{$_SESSION['e_id']}', 'Approved') ");
        	echo"<script>alert('Successfully added request!');window.location.href='all_request.php';</script>";
        }



        if (isset($_POST['employee_add_request'])) {
        	$Today = date('y:m:d');
			$date = date('F d, Y', strtotime($Today));
			$time = date_default_timezone_set("Asia/Manila");
			$timenow =date ('g:i A' ,time());

        	$type = $_POST['type'];
        	$desc = $_POST['desc'];
        	$purpose =$_POST['purpose'];
        	$return = $_POST['return'];

        	mysqli_query($con, "INSERT INTO tbl_requests (request_type, description, purpose, date_req, time_req, requested_by, return_on, employee_id, status) VALUES ('$type', '$desc', '$purpose', '$date', '$timenow', '{$_SESSION['e_id']}', '$return', '{$_SESSION['e_id']}', 'Pending') ");
        	echo"<script>alert('Successfully added request!');window.location.href='employee_all_requests.php';</script>";
        }




        if (isset($_POST['update_request'])) {
        	$key = $_POST['id_request'];	

        	$desc = $_POST['desc'];
        	$purpose = $_POST['purpose'];

        	mysqli_query($con, "UPDATE tbl_requests SET description ='$desc',  purpose = '$purpose' WHERE request_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='all_request.php';</script>";
        }


        if (isset($_POST['addclaim'])) {
        	$key = $_POST['key'];
        	$claim = $_POST['claim'];

        	mysqli_query($con, "UPDATE tbl_requests SET received_by = '$claim' where request_id = $key");
        	echo"<script>alert('Successfully added.');window.location.href='all_request.php';</script>";
        }



        if (isset($_POST['update_emp'])) {
        	$key = $_POST['use_id'];

        	$idnum = $_POST['idnum'];
			$lname = $_POST['lname'];
			$fname = $_POST['fname'];
			$mname = $_POST['mname'];
			$ename = $_POST['ename'];
			$nname = $_POST['nname'];
			$arank = $_POST['aranks'];
			$uposition = $_POST['uposition'];

			mysqli_query($con, "UPDATE tbl_employee SET id_number ='$idnum', lastname ='$lname', firstname ='$fname', middlename ='$mname', extension_name ='$ename', nickname ='$nname', academic_rank_id ='$arank', university_position_id ='$uposition' WHERE employee_id = '$key' ");
			echo"<script>alert('Successfully updated profile.');window.location.href='profile.php';</script>";
        }


        if (isset($_POST['update_employee'])) {
        	$key = $_POST['use_id'];

        	$idnum = $_POST['idnum'];
			$lname = $_POST['lname'];
			$fname = $_POST['fname'];
			$mname = $_POST['mname'];
			$ename = $_POST['ename'];
			$nname = $_POST['nname'];
			$arank = $_POST['aranks'];
			$uposition = $_POST['uposition'];

			mysqli_query($con, "UPDATE tbl_employee SET id_number ='$idnum', lastname ='$lname', firstname ='$fname', middlename ='$mname', extension_name ='$ename', nickname ='$nname', academic_rank_id ='$arank', university_position_id ='$uposition' WHERE employee_id = '$key' ");
			echo"<script>alert('Successfully updated profile.');window.location.href='employee_profile.php?id=$key';</script>";
        }



        if (isset($_POST['update_employee_profile'])) {
        	$key = $_POST['prof_id'];

        	$idnum = $_POST['idnum'];
			$lname = $_POST['lname'];
			$fname = $_POST['fname'];
			$mname = $_POST['mname'];
			$ename = $_POST['ename'];
			$nname = $_POST['nname'];
			$arank = $_POST['aranks'];
			$uposition = $_POST['uposition'];

			$q = mysqli_query($con, "UPDATE tbl_employee SET id_number ='$idnum', lastname ='$lname', firstname ='$fname', middlename ='$mname', extension_name ='$ename', nickname ='$nname', academic_rank_id ='$arank', university_position_id ='$uposition' WHERE employee_id = '$key' ");
			echo"<script>alert('Successfully updated profile.');window.history.back();</script>";
        }


        if (isset($_POST['update_announcement'])) {
        	$key = $_POST['id_announce'];	

        	$desc = $_POST['descrip'];
        	$title = $_POST['title'];

        	mysqli_query($con, "UPDATE tbl_announcements SET announcement_title = '$title', announcement_desc ='$desc'  WHERE announcements_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='settings.php';</script>";
        }


        if (isset($_POST['update_doctype'])) {
        	$key = $_POST['id_type'];
        	$title = $_POST['title4'];

        	mysqli_query($con, "UPDATE tbl_document_type SET document_type = '$title' WHERE document_type_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='document_type.php';</script>";
        }


        if (isset($_POST['update_userlevel'])) {
        	$key = $_POST['id_level'];
        	$level = $_POST['level'];

        	mysqli_query($con, "UPDATE tbl_userlevel SET user_level = '$level' WHERE userlevel_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='userlevel.php';</script>";
        }


        if (isset($_POST['update_position'])) {
        	$key = $_POST['id_pos'];
        	$position = $_POST['position'];

        	mysqli_query($con, "UPDATE tbl_university_position SET university_position = '$position' WHERE university_position_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='university_position.php';</script>";
        }


        if (isset($_POST['update_ranks'])) {
        	$key = $_POST['id_ranks'];
        	$rank = $_POST['rank'];
        	$acad_rank = $_POST['acad_rank'];
        	$salary = $_POST['salary'];
        	$points = $_POST['points'];

        	mysqli_query($con, "UPDATE tbl_academic_ranks SET rank = '$rank', academic_rank = '$acad_rank', salary_grade = '$salary', points = '$points' WHERE academic_rank_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='academic_ranks.php';</script>";
        }


        if (isset($_POST['update_account'])) {
        	$key = $_POST['id_acc'];
        	$username = $_POST['user123'];
        	$password = $_POST['pass123'];

        	mysqli_query($con, "UPDATE tbl_users SET username = '$username', password = '$password' WHERE employee_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='profile_edit.php?id=$key';</script>";
        }


        if (isset($_POST['update_account1'])) {
        	$key = $_POST['id_acc'];
        	$username = $_POST['user123'];
        	$password = $_POST['pass123'];

        	mysqli_query($con, "UPDATE tbl_users SET username = '$username', password = '$password' WHERE employee_id = '$key'");
        	echo"<script>alert('Successfully updated.');window.location.href='employee_profile_edit.php?id=$key';</script>";
        }



        if (isset($_POST['add_data_encoder'])) {
		
			$uname = $_POST['uname2'];
			$pass = $_POST['pass2'];
			
			
			mysqli_query($con, "INSERT INTO tbl_users (username, password, status, userlevel_id, employee_id, first_time_login) VALUES ('$uname', '$pass', 'offline',  '3', '56',  'logged')");
			echo"<script>alert('Successfully added new data encoder. Please advice your data encoder to be correct in all data entry. ');window.location.href='data_encoder.php';</script>";
			
		}



        if(isset($_POST['deactivate']))
        {
            $id2 = $_POST['id123'];
            $reason = $_POST['reason'];
            
            mysqli_query($con,"UPDATE tbl_employee SET reason= '$reason', status= 'inactive' where employee_id = '$id2'");
            echo"<script>alert('Successfully deactivated employee account. ');window.location.href='all_employee.php';</script>";
        }
     



	/*if (isset($_POST['add_employee'])) {
		$target_dir = "../assets/images/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				}

				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}

				 // Check file size
				if ($_FILES["fileToUpload"]["size"] > 500000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}

				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
	}*/


	if (isset($_POST['add_account'])) {
		
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];
		$employee = $_POST['employee_id'];
		
		$var=mysqli_query($con,"SELECT * FROM tbl_employee WHERE id_number= '$employee'");
		$count=mysqli_num_rows($var);

		if ($count == '1') {
			$sql = mysqli_query($con, "INSERT INTO tbl_users (username, password, status, userlevel_id, employee_id, first_time_login) VALUES ('$uname', '$pass', 'offline',  '2', (SELECT employee_id FROM tbl_employee WHERE id_number = '$employee' ),  '')");
			echo"<script>alert('Successfully added new user account. You can now proceed logging in. ');window.location.href='../index.php';</script>";
		}
		else{
			echo"<script>alert('Employee id number does not exist. Please contact the HR Office for adding your employee account.');window.location.href='register.php';</script>";
		}
		
	}



	if (isset($_POST['save_account'])) {
		$key = $_GET['id'];

		$name = $_FILES['myfile2']['name'];
        $tmp_name = $_FILES['myfile2']['tmp_name'];
		$user = $_POST['user'];
		$pass = $_POST['pass'];

		if ($name){

                $location = "images/$name";
                move_uploaded_file($tmp_name, $location); 
                $query   = mysqli_query($con,"UPDATE tbl_users SET username= '$user', password= '$pass', file='$name', path= '$location' where employee_id = $key)");
                echo"<script>alert('Successfully updated user account settings. ');window.location.href='employee_lists.php';</script>";

            }else{
                echo"<script>alert('Please select file!');window.history.back();</script>";
            }

	}



	
?>