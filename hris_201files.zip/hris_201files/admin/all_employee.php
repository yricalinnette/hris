<?php session_start();
    if(!isset($_SESSION['id'])){
        header("Location: ../index.php");
    }
    else{
      include ("session_end.php");
    
    }
?>
<!doctype html>
<html lang="en">
<head>
	<title>HRIS: 201 File</title>
    <link rel="icon" href="../assets/images/logo.png">
    <!-- Bootstrap core CSS     -->
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.min.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>

    <!--Style-->
    <style type="text/css">
        .card-body{
            padding: 20px;
        }
        .card {
            margin: 0 auto;
            float: none;
            margin-bottom: 10px;
        }
        input[type=text], input[type=password], select {
            padding: 12px 20px;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 8px;
        }
        .results tr[visible='false'],
        .no-result{
          display:none;
        }

        .results tr[visible='true']{
          display:table-row;
        }

        .counter{
          padding:8px; 
          color:#ccc;
        }
    </style>

</head>
<body>

<div class="wrapper">

    <?php
        include ("connection.php");

        $var= mysqli_query($con,"SELECT * FROM tbl_users WHERE users_id='$_SESSION[id]' ");
        $count=mysqli_num_rows($var);
          //echo $count;
          //I only specifies the admin accesslevel, if the $count=1, meaning the logged account is administrator or admin, else student or user

        if ($count)
        {
            if ($_SESSION['userlevel_id']== '1') {
    ?>

    <!--Kanan ha side bar-->
    <div class="sidebar" data-background-color="white" data-active-color="info">
        <div class="sidebar-wrapper">
            <div class="logo">
                <?php include "../templates/profile.php"; ?>
            
            </div>
            <ul class="nav">
                <li>
                    <a href="home.php">
                        <i class="ti-dashboard" style="height: 30px; width: 30px"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="upload_doc.php">
                        <i class="ti-upload" style="height: 30px; width: 30px"></i>
                        <p>Upload Document</p>
                    </a>
                </li>
                <li>
                    <a href="all_documents.php">
                        <i class="ti-book" style="height: 30px; width: 30px"></i>
                            <p>Documents</p>
                    </a>
                </li>
                <li  class="active">
                    <a href="all_employee.php">
                        <i class="ti-user" style="height: 30px; width: 30px"></i>
                            <p>Employees</p>
                    </a>
                </li>
                <li>
                    <a href="all_request.php">
                        <i class="ti-notepad" style="height: 30px; width: 30px"></i>
                            <p>Requests</p>
                    </a>
                </li>
                <li>
                    <a href="profile.php">
                        <i class="ti-info-alt" style="height: 30px; width: 30px"></i>
                            <p>Account Settings</p>
                    </a>
                </li>
                <li>
                    <a href="settings.php">
                        <i class="ti-settings" style="height: 30px; width: 30px"></i>
                            <p>Settings</p>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i><img src="../assets/img/logout.ico" style="height: 30px; width: 30px"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </div>
    </div><!--End han side bar-->

    <?php  
            }elseif ($_SESSION['userlevel_id']== '2') {
                include ('../templates/mis.php');
            }elseif ($_SESSION['userlevel_id']== '3') {
                include ('../templates/panel_encoder.php');
            }elseif ($_SESSION['userlevel_id']== '4') {
              include ('../templates/panel_employee.php');
            }
        }

        
    ?>

    <!--Main panel ini-->
    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#">All Employees</a>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12"  style="height: 600px; overflow: auto">
                        <div class="card">
                            <div class="header">
                                <div class="col-md-6">
                                    <input type="text" class="search form-control" placeholder="What are you looking for?">
                                    <!--<span class="counter"></span>-->
                                </div>
                                <div class="columns columns-right pull-right">
                                   
                                        <a href="all_inactive.php" class="btn btn-info" type="button" title="Received Mails">
                                            <i class="ti-timer"></i>
                                            <b> In-active Employees</b>    
                                        </a>
                                         <a href="add_employee.php" class="btn btn-info" type="button" title="Add Employee">
                                            <i class="ti-plus"></i>
                                            <b> Add Employee</b>    
                                        </a>
                                  
                                </div>
                                
                            </div>
                          <div class="panel-body">
                  <div class="table-responsive">
                      <table class="table table-hover" id="dataTables-example" style="color: black;">
                        <thead>
                          <tr>
                            <td>
                              <center><b>Employee ID No.</b></center>
                            </td>
                            <td>
                              <b>NAME</b>
                            </td>
                            <td>
                              <center><b>STATUS</b></center>
                            </td>
                            <td>
                              <center><b>ACTION</b></center>
                            </td>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                         
                              <?php
                                $results_per_page= 10; 


                                if (!isset($_GET['page'])){
                                  $page = 1;
                                }else{
                                  $page = $_GET['page'];
                                }

                                $this_page_first_result = ($page-1)*$results_per_page;

                                    $q=mysqli_query($con,"SELECT * FROM  tbl_employee WHERE employee_id <> 56 AND status='active' ORDER BY lastname ASC");

                                    $query=mysqli_query($con,"SELECT * from tbl_employee LIMIT " .$this_page_first_result. ',' .$results_per_page);
                                    $num=mysqli_num_rows($q); 

                                    echo "<tr>";
                                    while($row=mysqli_fetch_array($q))
                                    {
                                    echo "
                                    <tr >
                                    <td><center/><h5/>$row[id_number]
                                    <td><h5/><img src='../assets/images/$row[file]' style = 'width: 50px; border-radius: 150px; '>  $row[lastname], $row[firstname]   $row[middlename] $row[extension_name]
                                    <td><center/><h5 data-toggle='modal' data-target='#active' >$row[status]</a>
                                    <td><center/><a href='employee_profile.php?id=$row[employee_id]' class='btn btn-primary'><span class='fa fa-eye'></span> View</a>
                                    
                                    </tr>
                                    ";
                                    
                                  }
                                ?>
                     
                          </tr>

                        </tbody>
                      </table>
                    </div>
                 </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div><!--Content lwat adi na end-->


         <footer class="footer">
            <div class="container-fluid">
                <div class="copyright pull-right">
                    &copy; 2017,<i class="fa fa-briefcase"></i> LNU:HRMO by: ALT+F4 </a>
                </div>
            </div>
        </footer>

    </div><!--End han Main panel ini-->
</div><!--End han wrapper lwat-->

</body>
    <!-- Ha date ngan time -->
    <script>
        var dt = new Date();
            document.getElementById("datetime").value = dt.toLocaleString();
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
      $(".search").keyup(function () {
        var searchTerm = $(".search").val();
        var listItem = $('.results tbody').children('tr');
        var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
        
      $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
            return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
        }
      });
        
      $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','false');
      });

      $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
        $(this).attr('visible','true');
      });

      var jobCount = $('.results tbody tr[visible="true"]').length;
        $('.counter').text(jobCount + ' item');

      if(jobCount == '0') {$('.no-result').show();}
        else {$('.no-result').hide();}
          });
    });
    </script>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>


</html>
