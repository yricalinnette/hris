<?php
	include ('connection.php');

	

	if($_GET['set1']=='true6')
	{
		$id2 = $_GET['key'];
		mysqli_query($con,"UPDATE tbl_employee SET status= 'active' where employee_id = '$id2'");
		echo"<script>alert('Successfully activated employee account. ');window.location.href='all_employee.php';</script>";
	}
	

?>