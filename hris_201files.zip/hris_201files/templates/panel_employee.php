<!-- Navbar -->
<div class="w3-top">
 <div class="w3-padding-large w3-theme-d5 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a> 
  <a href="employee_home.php" class="w3-bar-item w3-button w3-padding-large w3-theme-d4"><i class="fa fa-home w3-margin-right"></i>HRIS: 201 Files</a>
  <a href="employee_upload.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Upload Document"><i class="fa fa-upload"></i></a>
  <a href="employee_documents.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Documents"><i class="fa fa-book"></i></a>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large" ><i class="fa fa-folder-open"></i></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="employee_add_request.php" class="w3-bar-item w3-button">Add Request</a>
      <a href="employee_all_requests.php" class="w3-bar-item w3-button">All Request</a>
    </div>
  </div>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Logs"><i class="fa fa-calendar-check-o"></i></a>
  <a href="profile.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user-circle"></i></a>
  <a href="../pages/logout.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="Logout" alt="Logout"><i class="fa fa-sign-out" style="color: orange;"></i></a>
 </div>
</div>