
          <?php include "fetching.php" ?>
          <center><h4 >Hi, <?php print ($nickname); ?> <i class='ti-comments-smiley'></i></h4>
          
          <img src="../assets/images/<?php  echo $file; ?> " style="height:90px;width:90px; border-radius: 50%;" alt="Avatar"></center>
        
        
          <!--<?php 

              $query = mysqli_query($con, "SELECT tbl_employee.lastname, tbl_employee.firstname, tbl_employee.middlename, tbl_employee.extension_name from tbl_users INNER JOIN tbl_employee ON tbl_users.employee_id=tbl_employee.employee_id where tbl_users.users_id = '{$_SESSION['id']}'" );

              while($row=mysqli_fetch_array($query))
              {
                echo"
                  <tr >
                  <td/><h5/><i class='ti-user '></i> $row[lastname], $row[firstname] $row[middlename]
                  </tr>
                ";
              }

          ?>
         <br><i class="ti-home"></i> 
           <?php 

              $query = mysqli_query($con, "SELECT tbl_university_position.university_position from tbl_university_position INNER JOIN tbl_employee ON tbl_employee.university_position_id=tbl_university_position.university_position_id where tbl_employee.employee_id = '{$_SESSION['e_id']}'" );

              while($row=mysqli_fetch_array($query))
              {
                echo"
                  <tr >
                  <td> $row[university_position]
                  </tr>
                ";
              }

          ?>
         <p> <?php
          if ($status == 'active') {
            echo "<i class='fa fa-eye fa-fw w3-margin-right w3-text-theme'></i> $status"; 
          }else{
            echo "<i class='fa fa-eye-slash fa-fw w3-margin-right w3-text-theme'></i> $status"; 
          }
          ?>
          </p>-->