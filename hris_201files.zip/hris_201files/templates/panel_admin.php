<!-- Navbar -->
<div class="w3-top">
 <div class="w3-padding-large w3-theme-d5 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="home.php" class="w3-bar-item w3-button w3-padding-large w3-theme-d4" data-toggle="tooltip" data-placement="bottom" title="Tooltip on bottom"><i class="fa fa-home w3-margin-right"></i>HRIS: 201 Files</a>
  <a href="admin_upload.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Upload Document"><i class="fa fa-upload"></i></a>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large" ><i class="fa fa-book"></i></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="admin_for_approval.php" class="w3-bar-item w3-button">For Approval</a>
      <a href="all_documents.php" class="w3-bar-item w3-button">All Documents</a>
    </div>
  </div>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large"><i class="fa fa-users"></i></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="add_employees.php" class="w3-bar-item w3-button">Add Employee</a>
      <a href="all_employees.php" class="w3-bar-item w3-button">Active Employee</a>
      <a href="all_inactive.php" class="w3-bar-item w3-button">In-active Employee </a>
    </div>
  </div>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large" ><i class="fa fa-tasks"></i></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="admin_add_request.php" class="w3-bar-item w3-button">Add Request</a>
      <a href="admin_pending_requests.php" class="w3-bar-item w3-button">Pending Requests</a>
      <a href="admin_all_request.php" class="w3-bar-item w3-button">All Requests</a>
    </div>
  </div>
  <!--<a href="generate_docs.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Generate Reports"><i class="fa fa-file-text-o"></i></a>-->
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Logs"><i class="fa fa-calendar-check-o"></i></a>
  <a href="profile.php" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user-circle"></i></a>
  <div class="w3-dropdown-hover w3-hide-small">
    <button class="w3-button w3-padding-large" ><i class="fa fa-cog fa-spin fa-1x fa-fw"></i></button>
    <div class="w3-dropdown-content w3-card-4 w3-bar-block" style="width:300px">
      <a href="announcement.php" class="w3-bar-item w3-button">Announcements</a>
      <a href="document_type.php" class="w3-bar-item w3-button">Document Types</a>
      <a href="academic_ranks.php" class="w3-bar-item w3-button">Academic Ranks</a>
      <a href="university_position.php" class="w3-bar-item w3-button">University Position</a>
      <a href="userlevel.php" class="w3-bar-item w3-button">User Level</a>
      <a href="data_encoder.php" class="w3-bar-item w3-button">Data Encoder</a>
    </div>
  </div>
  <a href="../pages/logout.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-white" title="Logout" alt="Logout"><i class="fa fa-sign-out" style="color: orange;"></i></a>
 </div>
</div>